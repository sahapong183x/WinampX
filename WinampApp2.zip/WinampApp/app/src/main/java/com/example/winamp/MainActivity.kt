package com.example.winamp

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooserCb: ValueCallback<Array<Uri>>? = null
    @Volatile private var playing = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        chooserCb?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        chooserCb = null
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    // Buttons shown in the floating (picture-in-picture) window
    private val remote = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = when (i.action) {
                "wa.prev" -> "prev"
                "wa.play" -> "pause"
                "wa.next" -> "next"
                else -> return
            }
            web.evaluateJavascript("document.getElementById('$id').click()", null)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(0xFF000000.toInt())
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // remembers EQ settings
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun s(p: Boolean) { playing = p }
        }, "WA")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                chooserCb?.onReceiveValue(null)
                chooserCb = cb
                picker.launch(arrayOf("audio/*", "video/mp4", "video/*"))
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        val f = IntentFilter().apply { addAction("wa.prev"); addAction("wa.play"); addAction("wa.next") }
        ContextCompat.registerReceiver(this, remote, f, ContextCompat.RECEIVER_NOT_EXPORTED)

        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        ContextCompat.startForegroundService(this, Intent(this, PlayerService::class.java))

        // Back button: keep playing in the background instead of closing
        onBackPressedDispatcher.addCallback(this) {
            if (playing) moveTaskToBack(true) else finish()
        }
    }

    private fun pip(): PictureInPictureParams {
        fun act(id: Int, icon: Int, title: String, action: String) = RemoteAction(
            Icon.createWithResource(this, icon), title, title,
            PendingIntent.getBroadcast(this, id, Intent(action).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE)
        )
        return PictureInPictureParams.Builder()
            .setAspectRatio(Rational(275, 116))   // shows the main player window
            .setActions(listOf(
                act(1, android.R.drawable.ic_media_previous, "Previous", "wa.prev"),
                act(2, android.R.drawable.ic_media_play, "Play/Pause", "wa.play"),
                act(3, android.R.drawable.ic_media_next, "Next", "wa.next")
            )).build()
    }

    // Leaving the app while music plays turns it into a floating window
    override fun onUserLeaveHint() {
        if (playing && Build.VERSION.SDK_INT >= 26) enterPictureInPictureMode(pip())
    }

    override fun onDestroy() {
        unregisterReceiver(remote)
        stopService(Intent(this, PlayerService::class.java))
        super.onDestroy()
    }
}
