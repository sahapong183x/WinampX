Winamp for Android - build steps
1. Install Android Studio and open this folder (WinampApp).
2. If asked about Gradle, accept the default / let it sync.
3. Plug in your phone (USB debugging on) and press Run,
   or Build > Build APK(s) and install app-debug.apk on the phone.
Floating window: while music plays, press Home - the player shrinks into a floating window
with previous / play-pause / next buttons. Back button keeps playing in the background.
